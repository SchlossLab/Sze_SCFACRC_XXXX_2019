#!/bin/bash


# Set up output directories
mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/processing
mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/assembly
mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/assembly/QC
mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/annotation
mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/mapping
mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/concoct


# Assign correct Nextera XT primer pair that was used (5' + 3' reverse complement)
if [ $1 = 'Conventional' ]
then
	F_primer=CAAGCAGAAGACGGCATACGAGATTAAGGCGAGTCTCGTGGGCTCGG
	R_primer=GACGCTGCCGACGAGCGATCTAGTGTAGATCTCGGTGGTCGCCGTATCATT
elif [ $1 = 'Cefoperazone' ]
then
	F_primer=CAAGCAGAAGACGGCATACGAGATAGGCAGAAGTCTCGTGGGCTCGG
	R_primer=GACGCTGCCGACGAAGAGGATAGTGTAGATCTCGGTGGTCGCCGTATCATT
elif [ $1 = 'Streptomycin' ]
then
	F_primer=CAAGCAGAAGACGGCATACGAGATTCCTGAGCGTCTCGTGGGCTCGG
	R_primer=GACGCTGCCGACGATCTACTCTGTGTAGATCTCGGTGGTCGCCGTATCATT
elif [ $1 = 'Clindamycin' ]
then
	F_primer=CAAGCAGAAGACGGCATACGAGATCGTACTAGGTCTCGTGGGCTCGG
	R_primer=AATGATACGGCGACCACCGAGATCTACACCTCTCTATTCGTCGGCAGCGTC
fi


# Lane pooling 
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/fastq/
pooling_job_id=$(qsub -v metagenome=$1 /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/pool.pbs | sed 's/\..*$//')
echo $1 read pooling job submitted. Job ID $pooling_job_id


# Adapter cutting and quality trimming
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/processing/
trimming_job_id=$(qsub -v metagenome=$1,forward=$F_primer,reverse=$R_primer -W depend=afterok:$pooling_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/trimming.pbs | sed 's/\..*$//')
echo $1 quality trimming job submitted. Job ID $trimming_job_id


# Assembly and quality control
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/assembly
assembly_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$trimming_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/assembly.pbs | sed 's/\..*$//')
echo $1 assembly job submitted. Job ID $assembly_job_id
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/assembly/QC
bowtie_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$assembly_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/metagenome2contigs.pbs | sed 's/\..*$//')
echo $1 read-to-contig mapping job submitted. Job ID $bowtie_job_id


# Gene calling, dereplication, and annotation
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/annotation
genes_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$assembly_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/gene_calling.pbs | sed 's/\..*$//')
echo $1 gene calling job submitted. Job ID $genes_job_id
dereplicate_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$genes_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/dereplication.pbs | sed 's/\..*$//')
echo $1 dereplication job submitted. Job ID $dereplicate_job_id
annotation_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$dereplicate_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/annotation.pbs | sed 's/\..*$//')
echo $1 annotation job submitted. Job ID $annotation_job_id


# Mapping reads to genes
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/mapping
db_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$annotation_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/metagenome_db.pbs | sed 's/\..*$//')
echo $1 gene database creation job submitted. Job ID $db_job_id


# Running CONCOCT to seperate into genomes
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/concoct
setup_concoct_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$assembly_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/preconcoct.pbs | sed 's/\..*$//')
echo $1 contig abundance job submitted. Job ID $setup_concoct_job_id
concoct_job_id=$(qsub -v metagenome=$1 -W depend=afterok:$setup_concoct_job_job_id /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/concoct.pbs | sed 's/\..*$//')
echo $1 CONCOCT job submitted. Job ID $concoct_job_id



echo
