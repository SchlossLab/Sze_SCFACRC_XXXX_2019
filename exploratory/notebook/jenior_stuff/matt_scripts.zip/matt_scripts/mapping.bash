#!/bin/bash


# Create directory for mapping metagenomic reads
#mkdir /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/mapping

# Create directories for mapping transcriptomic reads
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/metagenome
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/metagenome/include_Cdifficile
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/metagenome/remove_Cdifficile
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630/genome
#mkdir /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630/genes


# Map metagenomic reads to genes 
cd /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/$1/mapping
mapping0_job_id=$(qsub -v metagenome=$1,count=$3 /mnt/EXT/Schloss-data/matt/metagenomes_HiSeq/pbs/reads2genes.pbs | sed 's/\..*$//')
echo $1 metaG read-to-gene mapping job submitted. Job ID $mapping0_job_id


# Define which metatranscriptomes are to be mapped to each metagenome
if [ $1 = 'Cefoperazone' ]; then
	transcript_array=('cefoperazone_630' 'cefoperazone_mock')
elif [ $1 = 'Clindamycin' ]; then
	transcript_array=('clindamycin_630' 'clindamycin_mock')
elif [ $1 = 'Streptomycin' ]; then
	transcript_array=('streptomycin_630' 'streptomycin_mock')
elif [ $1 = 'Conventional' ]; then
	transcript_array=('conventional')
fi


# Map transcript reads to corresponding metagenome
for index in ${transcript_array[*]}
do
	cd /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/metagenome/include_Cdifficile
	mapping1_job_id=$(qsub -v metagenome=$1,metatranscriptome=$index,count=$2 /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/pbs/map2metagenome.pbs | sed 's/\..*$//')
	echo $index-to-$1 mapping job submitted. Job ID $mapping1_job_id
	cd /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/metagenome/remove_Cdifficile
	mapping2_job_id=$(qsub -v metagenome=$1,metatranscriptome=$index,count=$2 /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/pbs/map2metagenome_w_cdf.pbs | sed 's/\..*$//')
	echo $index-to-$1 with Cdifficile mapping job submitted. Job ID $mapping2_job_id
	
	# Map transcriptome containing C. difficile to the 630 genes and genome
	if [[ $index =~ '_630' ]]; then
		cd /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630/genome
		genome_job_id=$(qsub -v transcriptome=$index,count=$2 /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/pbs/map2cdf_genome.pbs | sed 's/\..*$//')
		echo $index-to-C.difficile630 genome mapping job submitted. Job ID $genome_job_id
		cd /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630/genes
		genes_job_id=$(qsub -v transcriptome=$index,count=$2 /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/pbs/map2cdf_genes.pbs | sed 's/\..*$//')
		echo $index-to-C.difficile630 genes mapping job submitted. Job ID $genes_job_id	
	elif [ $index = 'conventional' ]; then
		cd /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630/genome
		genome1_job_id=$(qsub -v transcriptome='germfree',count=$2 /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/pbs/map2cdf_genome.pbs | sed 's/\..*$//')
		echo Germfree-to-C.difficile630 genome mapping job submitted. Job ID $genome1_job_id
		cd /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mapping/cdifficile630/genes
		genes1_job_id=$(qsub -v transcriptome='germfree',count=$2 /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/pbs/map2cdf_genes.pbs | sed 's/\..*$//')
		echo Germfree-to-C.difficile630 genes mapping job submitted. Job ID $genes1_job_id
	fi
done


echo