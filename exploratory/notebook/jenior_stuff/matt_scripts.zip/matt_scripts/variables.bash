#!/bin/bash


# set sample name
reads = $1

# Project directory


# set reference directory
kegg = /mnt/EXT/Schloss-data/kegg/kegg/genes/fasta/kegg.diamond.prot.db
silva = /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/silva/silva_db
mus = /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/mus_musculus/mus_db
cdf = /mnt/EXT/Schloss-data/matt/metatranscriptomes_HiSeq/cdf/cdf_db

# set script locations
personal_scripts = /home/mljenior/scripts
schloss_scripts = /mnt/EXT/Schloss-data/bin/

# set program locations
personal_bin = /home/mljenior/bin/

# Select correct sequencing primers
if [ $1 = 'Conventional' ]; then
	F_primer=CAAGCAGAAGACGGCATACGAGATTAAGGCGAGTCTCGTGGGCTCGG
	R_primer=GACGCTGCCGACGAGCGATCTAGTGTAGATCTCGGTGGTCGCCGTATCATT
fi

if [ $1 = 'Cefoperazone' ]; then
	F_primer=CAAGCAGAAGACGGCATACGAGATAGGCAGAAGTCTCGTGGGCTCGG
	R_primer=GACGCTGCCGACGAAGAGGATAGTGTAGATCTCGGTGGTCGCCGTATCATT
fi

if [ $1 = 'Streptomycin' ]; then
	F_primer=CAAGCAGAAGACGGCATACGAGATTCCTGAGCGTCTCGTGGGCTCGG
	R_primer=GACGCTGCCGACGATCTACTCTGTGTAGATCTCGGTGGTCGCCGTATCATT
fi

if [ $1 = 'Clindamycin' ]; then
	F_primer=CAAGCAGAAGACGGCATACGAGATCGTACTAGGTCTCGTGGGCTCGG
	R_primer=AATGATACGGCGACCACCGAGATCTACACCTCTCTATTCGTCGGCAGCGTC
fi

# export all variables
export reads
export kegg
export personal_scripts
export schloss_scripts
export personal_bin
export F_primer
export R_primer
